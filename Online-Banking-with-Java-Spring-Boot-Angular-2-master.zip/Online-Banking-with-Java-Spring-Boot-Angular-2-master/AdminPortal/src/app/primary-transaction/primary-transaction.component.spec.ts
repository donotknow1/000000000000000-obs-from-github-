/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PrimaryTransactionComponent } from './primary-transaction.component';

describe('Component: PrimaryTransaction', () => {
  it('should create an instance', () => {
    let component = new PrimaryTransactionComponent();
    expect(component).toBeTruthy();
  });
});
